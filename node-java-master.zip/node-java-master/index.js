
module.exports = require("./lib/nodeJavaBridge");
